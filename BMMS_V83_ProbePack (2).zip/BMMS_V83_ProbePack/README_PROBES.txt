BMMS V8.3.1 Probe Pack

FIRST ROUND (run these first; each run = replace submitted .asc and run all 15 cases):
P00_V8_3_1_BASELINE.asc              Known-good control; should reproduce V8.3.1.
P01_ADAPTIVE_ROWMAX_EPILOGUE.asc     New scheduler + old/full row-max epilogue.
P02_NATIVE_OFF.asc                   Disables Native small-K; Tree remains on.
P03_TREE_OFF.asc                     Disables Tree GEMV; Native remains on.
P04_NATIVE_NO_N_SPLIT.asc            Native scheduler may split M but pN is forced to 1.
P05_NATIVE_MIN4_TILES.asc            Rejects over-fine split candidates (<4 64x128 Cube tiles/task).

OPTIONAL SECOND ROUND (only needed after Native cases are identified):
P06_NATIVE_K32_OFF.asc               K=32 Native falls back; other Native buckets unchanged.
P07_NATIVE_K64_OFF.asc               K=64 Native falls back; other Native buckets unchanged.
P08_NATIVE_K128_OFF.asc              K=128 Native falls back; other Native buckets unchanged.

For every file, save all 15 rows: Pass/Fail, latency, and preferably the displayed best latency.
Do NOT mix files within one run. Do NOT add any print/debug statement.
