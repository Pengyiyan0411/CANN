这批探针非常有信息量，而且已经推翻了我们上一轮的一个判断：**V8.3.1 的主要问题并不是“普遍 oversplit”**。更准确地说，现在已经能把 15 个点分成几类，并明确下一步该分别优化什么。

先说明判断标准：不同提交之间本身有少量波动。对 8～15 这类较大耗时 case，约 1–3% 的变化通常不能单独当作路径证据；对 1～4 这种 2–6 μs 的点，0.2 μs 就可能表现成 5–8%。所以我下面主要采用“**变化足够大 + 被另一支正交探针重复验证**”的证据。

## 最重要的发现：Native 真正命中的基本是 K=128

P02 是关闭整个 Native，P08 是只关闭 K=128 Native。两者的 15 维“延迟响应向量”相关系数我算出来约为：

$$
r=0.964
$$

而 P06（K32 Off）、P07（K64 Off）与 P02 的相关性分别只有约 `0.009` 和 `0.133`。

最典型的是：

| Case | V8.3.1 | Native Off | K128 Off |
| ---- | -----: | ---------: | -------: |
| 5    |   8.20 |       9.93 |     9.39 |
| 13   |  18.71 |      26.96 |    26.57 |
| 14   |  15.05 |      26.10 |    25.22 |

Case 13 关闭 Native 后慢 **44.1%**，关闭 K128 Native 后慢 **42.0%**；Case 14 分别慢 **73.4%** 和 **67.6%**。P02 和 P08 几乎在复现同一件事。 

所以可以比较有把握地说：

$$
\boxed{\text{当前排行榜真正值得优化的 Native 子族主要就是 K=128}}
$$

K32/K64 暂时**不要投入主要工程时间**。P06/P07 没有任何类似 Case 13/14 的强烈响应。 

---

## 第二个发现：我之前的“应该抑制 N-split”判断是错的

P04 强制：

```text
pN = 1
```

结果最震撼的是 Case 14：

$$
15.05\ \mu s \rightarrow 49.20\ \mu s
$$

直接变成 **3.27 倍**，慢了 **226.9%**。

Case 6：

$$
14.04\rightarrow15.29
$$

Case 7：

$$
12.68\rightarrow14.51
$$

也分别慢约 **8.9% / 14.4%**。

这意味着：

> **N-split 不是问题本身，至少对于 6、7、14，它是非常有价值甚至不可缺少的并行方式。**

特别是 Case 14，现在几乎已经证明：

```text
Native K128
+
pN > 1
```

是正确路线。

所以不要把 scheduler 改成：

```text
B → M → 尽量不切 N
```

这种过于简单的规则。

---

## 第三个发现：`MIN_TILES_PER_TASK=4` 这个思路同样被否掉了

P05 是我们专门验证“是不是切得太碎”的。

如果 oversplit 是 6/7 的主要问题，那么限制每个 task 至少 4 个 Cube tile 应该变快。

结果却相反：

```text
Case 6: 14.04 → 15.05   +7.2%
Case 7: 12.68 → 14.00  +10.4%
```

Case 14 也从 `15.05 → 15.80`。

所以现在可以明确修正上一轮判断：

$$
\boxed{\text{6/7 的问题不是 task 太多、太碎}}
$$

反而说明这些 case **需要比较细的并行粒度才能维持 occupancy**。

真正的问题更可能是：

> **V8.3 scheduler 的 M/N 切分比例不够好，而不是总 task 数太多。**

这两者区别很重要。

---

# Case 5 给了一个非常干净的结论：scalar epilogue 是负优化

P01 保留 V8.3 的 adaptive scheduler，但恢复 V8.2 的完整 row-max epilogue。

Case 5：

```text
V8.2       7.33 μs
V8.3.1     8.20 μs
P01        7.19 μs
```

P01 比 V8.3.1 快了 **12.3%**，甚至略快于 V8.2。

这个实验非常漂亮，因为它实际上把两个因素分开了：

```text
V8.2
  ↓ 换 adaptive scheduler，但保留旧 epilogue
P01 = 7.19
  ↓ 再换 scalar epilogue
V8.3.1 = 8.20
```

所以 Case 5 的退化几乎可以直接归到：

$$
\boxed{\text{新的 scalar-partial epilogue}}
$$

而不是 scheduler。

Case 13 也有同样趋势：

```text
18.71 → 17.92 μs
```

恢复 row-max 后快约 **4.2%**。

这告诉我们一件很实际的事情：

> `pN==1` 时，scalar epilogue **不能无条件使用**。

我们的初衷是：

```text
[B,M] row maxima
→
[B,pM] scalar partial
```

降低 GM 流量。

但对于 M 不够大的场景，TwoSum、额外 vector 指令、同步和 scalar merge 的固定成本，反而比直接写一小段 row-max 更贵。

所以 V8.4 应该是**双 epilogue 自适应**：

```cpp
if (pN == 1 && rowMaxTrafficIsSmall)
    RowMaxEpilogue();
else
    ScalarEpilogue();
```

而不是删掉 scalar epilogue。大 M 时它仍可能有价值。

---

# Cases 6/7 的问题已经进一步缩小：是“切分方向”，不是“切分数量”

这是这轮最值得继续挖的地方。

比较：

|        |  V8.2 | P01：新 scheduler + 旧 epilogue | V8.3.1 |
| ------ | ----: | ---------------------------: | -----: |
| Case 6 | 12.89 |                        14.41 |  14.04 |
| Case 7 | 11.40 |                        12.83 |  12.68 |

P01 已经去除了 scalar epilogue 这个变量，但仍然比 V8.2 慢：

* Case 6：约 **+11.8%**
* Case 7：约 **+12.5%**

因此 6/7 的退化确实来自 scheduler 一侧。

但是：

```text
禁 N-split → 更慢
禁止细 task → 更慢
```

所以不能简单地减少并行。

我现在更怀疑的是：

### V8.3 把 M 切得太积极了

V8.2 的逻辑是：

```cpp
mChunks = ceil(M / 256);
```

也就是 M 方向基本以 `AM=256` 为大粒度。

在此基础上，再主要通过：

```text
N panels
```

把核心填满。

而 V8.3 可以把：

```text
64×128 Cube tile
```

直接作为 pM/pN 划分基础。

所以一个很合理的解释是：

```text
V8.3:
为了达到相同 task 数
→ 多切了一部分 M
→ B matrix 被重复加载更多次
```

而真正更好的策略可能是：

$$
\boxed{
\text{M 保持约 256 的粗粒度}
+
\text{更多依靠 N-split 补 occupancy}
}
$$

这和 P04/P05 的结果完全不矛盾：

* 不能取消 N split；
* 不能粗暴减少 task；
* 但是可以**改变相同 task 数下的 pM:pN 比例**。

下一轮我最想验证这个。

---

# Cases 13 和 14 已经成为两个很好的“Native 正反教材”

### Case 13

```text
Native Off:   18.71 → 26.96
K128 Off:     18.71 → 26.57
RowMax:       18.71 → 17.92
No N Split:   18.71 → 19.82
```

所以它基本是：

$$
\text{Native K128 有效}
$$

但 scalar epilogue 又吃掉了一部分收益。 

### Case 14

```text
Native Off:   15.05 → 26.10
K128 Off:     15.05 → 25.22
No N Split:   15.05 → 49.20
RowMax:       15.05 → 14.99
```

这就更清楚：

$$
\boxed{\text{K128 Native + N split 是绝对正确的}}
$$

而 row-max/scalar 对它基本没影响，说明它大概率本来就在：

```text
pN > 1
```

路径，所以不会用 `pN==1` scalar partial。 

这两个 case 可以用来保护下一版：

> 改 scheduler 时，**Case 14 不能退化**。

---

# 然后是最重要的坏消息，也是最大的机会：8 和 15 完全不在 V8.3 新路径里

Case 8 在所有探针中：

```text
90.33 ~ 92.81 μs
```

Case 15：

```text
108.20 ~ 112.32 μs
```

不论：

```text
关 Native
关 Tree
关 K32
关 K64
关 K128
禁 N split
改 task 粒度
换 epilogue
```

都基本纹丝不动。  

而它们的最优时间分别是：

```text
Case 8   17.32 μs
Case 15   9.04 μs
```

也就是说：

$$
\text{Case 8}=5.30\times\text{best}
$$

$$
\text{Case 15}=12.15\times\text{best}
$$

这已经可以非常明确地说：

$$
\boxed{\text{继续调 V8.3 Native scheduler 不可能解决 8 和 15}}
$$

它们根本走的是继承的 `bmms80d / bmms71` 路径。

尤其 Case 15，是当前最大机会。

---

# 事实上，主要优化空间已经高度集中

我按：

$$
t_{\text{ours}}-t_{\text{best}}
$$

算了一下绝对 headroom。

仅：

```text
8 / 9 / 10 / 11 / 15
```

五个 case 就占全部 15 个 case 总绝对差距的约：

$$
\boxed{86.0\%}
$$

所以从比赛工程角度，后面再去为了 Case 1：

```text
2.63 → 2.4
```

花一天时间，意义已经很小。

真正应该攻的是：

```text
15 > 11 > 8 > 10 ≈ 9
```

按绝对潜在 μs 排。

其中 Case 15 单点还有：

$$
109.81-9.04=100.77\ \mu s
$$

的差距。

---

# Tree 探针也给了一个信息：当前官方点里没有一个“干净的 Tree 主导点”

P03 Tree Off 后，没有出现类似：

```text
15 → 50 μs
```

这种独特变化。

6/7 虽然慢了约 12–14%，但它们同时对：

```text
Native Off
K128 Off
No N Split
Min4
```

也敏感，所以这并不是一个干净的 Tree fingerprint。

因此暂时不应该优先优化 V8.3 的 Tree kernel。

更值得查的是：

> Case 15 是不是走了另一种 degenerate family。

我看当前代码里，Tree 只接：

```cpp
M1_NContig
N1_MContig
```

但另外还有：

```cpp
M1_KContig
N1_KContig
```

它们仍走旧的 `bmms71::Skinny`。

所以 **Case 15 很值得怀疑是不是这个旧 Skinny family**。

注意我现在只能说“高价值假说”，还不能说它一定是，因为现有探针还没直接隔离这个 family。

---

# 我现在会把 15 个点这样分类

| Case   | 当前判断                                      | 信心 | 后续              |
| ------ | ----------------------------------------- | -- | --------------- |
| 1–4    | 非本轮 Native/Tree 主要对象                      | 高  | 暂时不管            |
| **5**  | **Native K128；pN≈1；scalar epilogue 明显不好** | 很高 | 恢复小规模 RowMax    |
| **6**  | Native K128 倾向；需要 N split/细粒度             | 中高 | 调 pM:pN 比例      |
| **7**  | Native K128 倾向；需要 N split/细粒度             | 中高 | 调 pM:pN 比例      |
| **8**  | **继承 fallback family**                    | 很高 | 新一轮 family 探针   |
| 9      | fallback                                  | 高  | 后续专项            |
| 10     | fallback                                  | 高  | 后续专项            |
| 11     | fallback                                  | 高  | 后续专项            |
| 12     | fallback，但已经接近 best                       | 高  | 保护              |
| **13** | **Native K128；RowMax 略优**                 | 很高 | hybrid epilogue |
| **14** | **Native K128；N split 极其关键**              | 极高 | 保护当前策略          |
| **15** | **继承 fallback；灾难点**                       | 极高 | 第一优先级查 family   |

---

## 所以下一轮我不建议直接上 128×128

探针之后，路线应该改。

### 第一组：把 Native K128 修干净

做三个非常针对性的 probe：

```text
A. pM 不得超过 ceil(M/256)
   pN 仍自由
```

这是验证“6/7 是不是 M 切太碎”。

```text
B. pM = V8.2 式 mChunks
   pN adaptive
```

进一步验证 V8.2 的 M 粗粒度是不是关键。

```text
C. Hybrid epilogue
   小 row-max traffic → RowMax
   大 row-max traffic → scalar
```

C 可以再用几个 threshold 做二分，不需要打印 shape。

### 第二组：直接查 Case 15 / 8 属于哪个旧 family

下一套路径探针我建议做：

```text
F01 Resident OFF
F02 old Skinny(M1_KContig/N1_KContig) OFF
F03 TrySmallKFamily OFF
F04 generic Fast path OFF
F05 generic Safe path OFF
```

每份仍然只是让某一 family 走另一个正确 fallback。

这样 Case 15 一旦出现：

```text
109 → 200
```

或者：

```text
109 → 20
```

我们马上就知道它在哪里。

---

### 我现在最看重的一条路线

如果 Case 15 最后证明是：

```text
M1_KContig / N1_KContig
→ old bmms71 Skinny
```

那就非常好。

因为这意味着不是去优化一个巨大 generic GEMM，而是可以专门写：

$$
\boxed{\text{一个新的退化 GEMV / reduction kernel}}
$$

而它的 best 已经告诉我们这条 shape 理论上可以做到 **9 μs 级**。

这可能是整个比赛里最大的一刀。

所以这轮探针非常成功：它已经让我们从之前“全局继续调 scheduler”，缩到了两个明确问题：

$$
\boxed{\text{Native K128：修 epilogue + 修 pM:pN}}
$$

以及

$$
\boxed{\text{Case 8/15：定位并替换 inherited fallback family}}
$$

如果你愿意，我下一步就直接给你做 **第二轮 Probe Pack**。这次不会再泛泛跑 8 个版本，而是专门围绕 **6/7 的 pM:pN** 和 **8/15 的 fallback family** 做 6～7 个高信息量探针。
